# Android_Project
Here is the source code for the android Application for ordering food i.e., Treat Your Tummy.
